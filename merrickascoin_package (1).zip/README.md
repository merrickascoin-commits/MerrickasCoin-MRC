# MerrickasCoin (MRC)

The Safe Meme on Base  
Veteran Founded | 0% Tax | Liquidity Locked Until 2028 | Verified Contract | Ongoing Burns

## 🔥 Contract Address
`0xb7D99C1F91aa68662476bD550b34f36798fFc0d7`

## 📊 Tokenomics
- Total Supply: 1,000,000,000,000 MRC
- Taxes: 0% Buy / 0% Sell
- Liquidity Locked Until 2028
- Burns: Ongoing (On-chain)

## 🔗 Links
- [BaseScan](https://basescan.org/token/0xb7D99C1F91aa68662476bD550b34f36798fFc0d7)
- [DEXTools](https://www.dextools.io/app/en/base/pair-explorer/)
- [Uniswap (Buy MRC)](https://app.uniswap.org/)
- [Telegram](#)
- [Twitter](#)
